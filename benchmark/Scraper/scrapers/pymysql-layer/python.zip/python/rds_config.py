#config file containing credentials for RDS MySQL instance
db_username = "adminadmin"
db_password = "password"
db_name = "BenchpressDB"
host = "benchpressinstance.cqjafdinqcl3.us-east-1.rds.amazonaws.com"