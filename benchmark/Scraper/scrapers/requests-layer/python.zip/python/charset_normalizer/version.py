"""
Expose version
"""

__version__ = "2.0.8"
VERSION = __version__.split(".")
